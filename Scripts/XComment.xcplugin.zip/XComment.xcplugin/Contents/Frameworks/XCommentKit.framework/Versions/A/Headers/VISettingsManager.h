//
//  VISettingsManager.h
//  VIXcode
//
//  Created by Ryan Wang on 4/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *VISettingsManagerEnableNotification = @"VISettingsManagerEnableNotification";

@interface VISettingsManager : NSObject

+ (VISettingsManager *)sharedSettingsManager;

- (BOOL)isVIMEnabled;
- (void)setVIMEnabled:(BOOL)flag;

- (void)insertMenu;

@end
